import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { motion, AnimatePresence } from "framer-motion";
import {
  Calendar as CalendarIcon,
  Clock,
  CheckCircle,
  CreditCard,
  ChevronLeft,
  ChevronRight,
  Lock,
  Smartphone,
  Wallet,
  Building2,
  QrCode,
  ShieldCheck,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/components/ui/use-toast";
import { createICSFile } from "@/lib/calendar";
import { useLocation, useNavigate } from "react-router-dom";
import { createBooking, getCounsellors } from "@/lib/storage";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";
import emailjs from "@emailjs/browser";

const TEMPLATE_BOOKER_ID = "template_odsk9gn";
const TEMPLATE_HOST_ID = "template_60qd3ws";

const toMeetSegment = (value = "") =>
  value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");

const BookAppointment = () => {
  const location = useLocation();
  const navigate = useNavigate();

  // Steps: 1=Details, 2=DateTime, 3=Payment, 4=Success
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [bookingComplete, setBookingComplete] = useState(false);
  const [confirmationData, setConfirmationData] = useState(null);

  // Payment State
  const [paymentMethod, setPaymentMethod] = useState("card");
  const [paymentDetails, setPaymentDetails] = useState({
    cardNumber: "",
    cardExpiry: "",
    cardCvc: "",
    upiId: "",
    bankName: "",
  });

  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    selectedService: "",
    selectedDate: undefined,
    selectedTime: "",
    selectedCounsellor: "",
    issue: "",
  });

  const [allCounsellors, setAllCounsellors] = useState([]);

  useEffect(() => {
    const counsellors = getCounsellors();
    setAllCounsellors(counsellors);

    const queryParams = new URLSearchParams(location.search);
    const counsellorId = queryParams.get("counsellor");
    if (counsellorId && counsellors.some((c) => c.id === counsellorId)) {
      setFormData((prev) => ({ ...prev, selectedCounsellor: counsellorId }));
    }
  }, [location.search]);

  const services = [
    {
      id: "discovery",
      name: "Discovery Call (30 min)",
      price: "Free",
      duration: 30,
    },
    {
      id: "counselling",
      name: "Counselling Session (60 min)",
      price: "$80",
      duration: 60,
    },
    {
      id: "stress",
      name: "Stress Management (45 min)",
      price: "$65",
      duration: 45,
    },
    {
      id: "mindfulness",
      name: "Mindfulness Coaching (45 min)",
      price: "$65",
      duration: 45,
    },
  ];

  const timeSlots = [
    "09:00 AM",
    "10:00 AM",
    "11:00 AM",
    "12:00 PM",
    "01:00 PM",
    "02:00 PM",
    "03:00 PM",
    "04:00 PM",
    "05:00 PM",
  ];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handlePaymentChange = (e) => {
    const { name, value } = e.target;
    setPaymentDetails((prev) => ({ ...prev, [name]: value }));
  };

  const handleFieldSelect = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const nextStep = () => {
    if (step === 1) {
      if (
        !formData.fullName ||
        !formData.email ||
        !formData.phone ||
        !formData.selectedService ||
        !formData.selectedCounsellor
      ) {
        toast({
          title: "Incomplete Details",
          description: "Please fill in all personal and service details.",
          variant: "destructive",
        });
        return;
      }
      setStep(2);
    } else if (step === 2) {
      if (!formData.selectedDate || !formData.selectedTime || !formData.issue) {
        toast({
          title: "Date & Time Required",
          description: "Please select a date, time, and describe your issue.",
          variant: "destructive",
        });
        return;
      }
      setStep(3);
    }
  };

  const prevStep = () => setStep(step - 1);

  const handlePaymentAndBooking = async () => {
    setIsSubmitting(true);

    // Simulate payment processing delay & Razorpay interaction
    if (paymentMethod === "razorpay") {
      toast({
        title: "Connecting to Razorpay...",
        description: "Secure gateway initialized.",
      });
      await new Promise((resolve) => setTimeout(resolve, 1500));
      toast({
        title: "Payment Authorized",
        description: "Transaction completed successfully via Razorpay.",
      });
    } else {
      await new Promise((resolve) => setTimeout(resolve, 2000));
    }

    const serviceDetails = services.find(
      (s) => s.id === formData.selectedService,
    );
    const counsellorDetails = allCounsellors.find(
      (c) => c.id === formData.selectedCounsellor,
    );
    const formattedDate = format(formData.selectedDate, "yyyy-MM-dd");
    const fullDateTime = `${format(formData.selectedDate, "EEEE, dd MMM yyyy")} at ${formData.selectedTime}`;
    const meetLink = `https://meet.jit.si/sukoon-session-${toMeetSegment(formData.fullName)}-${formattedDate}`;

    const bookingData = {
      full_name: formData.fullName,
      email: formData.email,
      phone: formData.phone,
      service_type: serviceDetails.name,
      service_id: formData.selectedService,
      counsellor_name: counsellorDetails.name,
      counsellor_id: formData.selectedCounsellor,
      appointment_date: formattedDate,
      appointment_time: formData.selectedTime,
      issue_description: formData.issue,
      price: serviceDetails.price,
      payment_method: paymentMethod,
      transaction_id: `txn_${Math.random().toString(36).substr(2, 9)}`, // Simulated Transaction ID
    };

    try {
      createBooking(bookingData);

      const serviceId = import.meta.env.VITE_EMAILJS_SERVICE_ID;
      const publicKey = import.meta.env.VITE_EMAILJS_PUBLIC_KEY;
      const hostEmail =
        counsellorDetails?.email ||
        counsellorDetails?.contactEmail ||
        import.meta.env.VITE_HOST_EMAIL ||
        "";

      if (serviceId && publicKey) {
        try {
          const sendPromises = [
            emailjs.send(
              serviceId,
              TEMPLATE_BOOKER_ID,
              {
                booker_person: formData.fullName,
                booker_name: formData.fullName,
                booked_date: formattedDate,
                time: fullDateTime,
                host_name: counsellorDetails.name,
                meet_link: meetLink,
                booker_email: formData.email,
              },
              { publicKey },
            ),
          ];

          if (hostEmail) {
            sendPromises.push(
              emailjs.send(
                serviceId,
                TEMPLATE_HOST_ID,
                {
                  booker_person: formData.fullName,
                  booker_name: formData.fullName,
                  email: formData.email,
                  phone: formData.phone,
                  booked_date: formattedDate,
                  booked_time: formData.selectedTime,
                  time: fullDateTime,
                  meet_link: meetLink,
                  notes: formData.issue,
                  host_email: hostEmail,
                },
                { publicKey },
              ),
            );
          } else {
            console.warn(
              "Host email not found for selected counsellor; host email notification skipped.",
            );
          }

          await Promise.all(sendPromises);
        } catch (emailError) {
          console.error("EmailJS send failed:", emailError);
          toast({
            title: "Booking Confirmed, Email Pending",
            description:
              "Your session is booked, but we could not send all confirmation emails right now.",
            variant: "destructive",
          });
        }
      } else {
        console.warn(
          "EmailJS not configured. Set VITE_EMAILJS_SERVICE_ID and VITE_EMAILJS_PUBLIC_KEY.",
        );
      }

      setConfirmationData({
        name: formData.fullName,
        email: formData.email,
        service: serviceDetails.name,
        counsellor: counsellorDetails.name,
        date: formattedDate,
        time: formData.selectedTime,
        meetLink,
        paymentMethod:
          paymentMethod === "razorpay"
            ? "Razorpay Secure"
            : paymentMethod.toUpperCase(),
      });

      setBookingComplete(true);
      setStep(4);

      toast({
        title: "Booking Successful!",
        description: "A confirmation email has been sent to you.",
      });

      // Auto download calendar
      try {
        const icsBlob = createICSFile({
          serviceName: serviceDetails.name,
          counsellorName: counsellorDetails.name,
          date: formattedDate,
          time: formData.selectedTime,
        });
        const url = URL.createObjectURL(icsBlob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "sukoon-world-appointment.ics";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } catch (e) {
        console.error("Calendar gen failed", e);
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderProgressBar = () => (
    <div className="flex justify-between mb-8 relative">
      <div className="absolute top-1/2 left-0 w-full h-1 bg-gray-200 -z-10"></div>
      {[1, 2, 3].map((s) => (
        <div key={s} className={`flex flex-col items-center bg-white px-2`}>
          <div
            className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm transition-colors duration-300
            ${step >= s ? "bg-primary text-white" : "bg-gray-200 text-gray-500"}`}
          >
            {s}
          </div>
          <span className="text-xs mt-1 font-medium text-gray-500">
            {s === 1 ? "Details" : s === 2 ? "Schedule" : "Payment"}
          </span>
        </div>
      ))}
    </div>
  );

  const getPaymentIcon = (method) => {
    switch (method) {
      case "card":
        return <CreditCard className="w-5 h-5" />;
      case "upi":
        return <Smartphone className="w-5 h-5" />;
      case "netbanking":
        return <Building2 className="w-5 h-5" />;
      case "wallet":
        return <Wallet className="w-5 h-5" />;
      case "razorpay":
        return <ShieldCheck className="w-5 h-5" />;
      default:
        return <CreditCard className="w-5 h-5" />;
    }
  };

  if (bookingComplete && confirmationData) {
    return (
      <section className="py-20 min-h-screen flex items-center justify-center bg-gray-50">
        <div className="max-w-xl w-full mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-2xl shadow-xl p-8 text-center"
          >
            <CheckCircle className="h-20 w-20 text-green-500 mx-auto mb-6" />
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Booking Confirmed!
            </h1>
            <p className="text-gray-600 mb-8">
              We've sent a confirmation to{" "}
              <span className="font-semibold">{confirmationData.email}</span>
            </p>
            <div className="bg-gray-50 rounded-xl p-6 mb-8 text-left space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-500">Service</span>{" "}
                <span className="font-medium">{confirmationData.service}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Date</span>{" "}
                <span className="font-medium">{confirmationData.date}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Time</span>{" "}
                <span className="font-medium">{confirmationData.time}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Counsellor</span>{" "}
                <span className="font-medium">
                  {confirmationData.counsellor}
                </span>
              </div>
              <div className="flex justify-between border-t border-gray-200 pt-3 mt-3">
                <span className="text-gray-500">Payment</span>{" "}
                <span className="font-medium flex items-center gap-1">
                  <CheckCircle className="w-3 h-3 text-green-500" />{" "}
                  {confirmationData.paymentMethod}
                </span>
              </div>
            </div>
            <Button
              onClick={() => navigate("/book")}
              className="w-full rounded-full"
            >
              Book Another Session
            </Button>
            <Button
              variant="ghost"
              onClick={() => navigate("/")}
              className="mt-4 w-full"
            >
              Return Home
            </Button>
          </motion.div>
        </div>
      </section>
    );
  }

  return (
    <>
      <Helmet>
        <title>Book Appointment - Sukoon World</title>
      </Helmet>

      <section className="py-12 bg-gray-50 min-h-screen">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-2xl shadow-xl p-6 md:p-10">
            <h1 className="text-3xl font-bold text-center mb-8 font-poppins text-secondary">
              Book Your Session
            </h1>
            {renderProgressBar()}

            <AnimatePresence mode="wait">
              {step === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <div className="md:col-span-2">
                      <Label>Select Service</Label>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
                        {services.map((service) => (
                          <div
                            key={service.id}
                            onClick={() =>
                              handleFieldSelect("selectedService", service.id)
                            }
                            className={`p-4 border-2 rounded-xl cursor-pointer transition-all ${formData.selectedService === service.id ? "border-primary bg-primary/5" : "border-gray-100 hover:border-primary/30"}`}
                          >
                            <div className="font-medium">{service.name}</div>
                            <div className="text-primary text-sm font-semibold">
                              {service.price}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="md:col-span-2">
                      <Label>Select Counsellor</Label>
                      <div className="grid grid-cols-1 gap-3 mt-2">
                        {allCounsellors.map((counsellor) => (
                          <div
                            key={counsellor.id}
                            onClick={() =>
                              handleFieldSelect(
                                "selectedCounsellor",
                                counsellor.id,
                              )
                            }
                            className={`p-3 border-2 rounded-xl cursor-pointer flex items-center gap-3 transition-all ${formData.selectedCounsellor === counsellor.id ? "border-primary bg-primary/5" : "border-gray-100 hover:border-primary/30"}`}
                          >
                            <img
                              src={counsellor.image}
                              alt={counsellor.name}
                              className="w-10 h-10 rounded-full object-cover"
                            />
                            <div>
                              <div className="font-medium text-sm">
                                {counsellor.name}
                              </div>
                              <div className="text-xs text-gray-500">
                                {counsellor.specialties.slice(0, 2).join(", ")}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="md:col-span-2 space-y-4">
                      <div>
                        <Label>Full Name</Label>
                        <Input
                          name="fullName"
                          value={formData.fullName}
                          onChange={handleInputChange}
                          placeholder="John Doe"
                        />
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label>Email</Label>
                          <Input
                            name="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            placeholder="john@example.com"
                          />
                        </div>
                        <div>
                          <Label>Phone</Label>
                          <Input
                            name="phone"
                            value={formData.phone}
                            onChange={handleInputChange}
                            placeholder="+1 234 567 890"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <Button onClick={nextStep} className="rounded-full px-8">
                      Next Step <ChevronRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </motion.div>
              )}

              {step === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                    <div>
                      <Label className="mb-2 block">Select Date</Label>
                      <div className="border rounded-lg p-2 flex justify-center">
                        <Calendar
                          mode="single"
                          selected={formData.selectedDate}
                          onSelect={(date) =>
                            handleFieldSelect("selectedDate", date)
                          }
                          className="rounded-md"
                          disabled={(date) =>
                            date < new Date() || date < new Date("1900-01-01")
                          }
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="mb-2 block">Select Time</Label>
                      <div className="grid grid-cols-2 gap-2">
                        {timeSlots.map((time) => (
                          <div
                            key={time}
                            onClick={() =>
                              handleFieldSelect("selectedTime", time)
                            }
                            className={`p-2 text-center border rounded-lg cursor-pointer text-sm ${formData.selectedTime === time ? "bg-primary text-white border-primary" : "hover:border-primary"}`}
                          >
                            {time}
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="md:col-span-2">
                      <Label>What would you like to discuss?</Label>
                      <Textarea
                        name="issue"
                        value={formData.issue}
                        onChange={handleInputChange}
                        placeholder="Briefly describe your main concern..."
                        className="mt-2"
                      />
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <Button
                      variant="outline"
                      onClick={prevStep}
                      className="rounded-full px-8"
                    >
                      <ChevronLeft className="mr-2 h-4 w-4" /> Back
                    </Button>
                    <Button onClick={nextStep} className="rounded-full px-8">
                      Proceed to Payment{" "}
                      <ChevronRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </motion.div>
              )}

              {step === 3 && (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.3 }}
                >
                  {/* Summary Header */}
                  <div className="bg-gray-50 p-4 rounded-xl mb-6 flex justify-between items-center border border-gray-100">
                    <div>
                      <p className="text-sm text-gray-500">
                        Total Payable Amount
                      </p>
                      <p className="text-2xl font-bold text-gray-900">
                        {
                          services.find(
                            (s) => s.id === formData.selectedService,
                          )?.price
                        }
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">
                        {
                          services.find(
                            (s) => s.id === formData.selectedService,
                          )?.name
                        }
                      </p>
                      <p className="text-xs text-gray-500">
                        {formData.selectedDate &&
                          format(formData.selectedDate, "MMM dd")}{" "}
                        at {formData.selectedTime}
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-col md:flex-row gap-8 mb-8">
                    {/* Payment Methods Sidebar */}
                    <div className="w-full md:w-1/3 space-y-2">
                      <Label className="mb-2 block">Payment Method</Label>
                      {[
                        {
                          id: "card",
                          label: "Credit/Debit Card",
                          icon: CreditCard,
                        },
                        { id: "upi", label: "UPI / QR Code", icon: Smartphone },
                        {
                          id: "razorpay",
                          label: "Razorpay Secure",
                          icon: ShieldCheck,
                        },
                        {
                          id: "netbanking",
                          label: "Net Banking",
                          icon: Building2,
                        },
                        { id: "wallet", label: "Wallets", icon: Wallet },
                      ].map((method) => (
                        <div
                          key={method.id}
                          onClick={() => setPaymentMethod(method.id)}
                          className={`p-3 rounded-lg flex items-center gap-3 cursor-pointer transition-all border 
                             ${
                               paymentMethod === method.id
                                 ? "bg-primary/10 border-primary text-primary font-medium shadow-sm"
                                 : "bg-white border-gray-100 hover:bg-gray-50 hover:border-gray-200"
                             }`}
                        >
                          <method.icon
                            className={`w-5 h-5 ${paymentMethod === method.id ? "text-primary" : "text-gray-400"}`}
                          />
                          <span>{method.label}</span>
                        </div>
                      ))}
                    </div>

                    {/* Payment Details Form */}
                    <div className="w-full md:w-2/3 bg-white border border-gray-100 rounded-xl p-6 shadow-sm">
                      {paymentMethod === "card" && (
                        <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                          <h3 className="font-semibold text-lg flex items-center mb-2">
                            Enter Card Details
                          </h3>
                          <div className="space-y-3">
                            <div>
                              <Label>Card Number</Label>
                              <Input
                                name="cardNumber"
                                placeholder="0000 0000 0000 0000"
                                onChange={handlePaymentChange}
                              />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <Label>Valid Thru</Label>
                                <Input
                                  name="cardExpiry"
                                  placeholder="MM/YY"
                                  onChange={handlePaymentChange}
                                />
                              </div>
                              <div>
                                <Label>CVV</Label>
                                <Input
                                  name="cardCvc"
                                  type="password"
                                  placeholder="123"
                                  onChange={handlePaymentChange}
                                />
                              </div>
                            </div>
                            <div>
                              <Label>Cardholder Name</Label>
                              <Input placeholder="Name on card" />
                            </div>
                          </div>
                        </div>
                      )}

                      {paymentMethod === "upi" && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                          <h3 className="font-semibold text-lg mb-2">
                            Pay via UPI
                          </h3>
                          <div className="flex flex-col items-center p-4 bg-gray-50 rounded-lg border border-dashed border-gray-300">
                            <QrCode className="w-32 h-32 text-gray-800 mb-2" />
                            <p className="text-sm text-gray-500 mb-4">
                              Scan QR code with any UPI App
                            </p>
                            <div className="w-full max-w-xs text-center border-t border-gray-200 pt-4 mt-2">
                              <p className="text-xs text-gray-400 mb-2">
                                OR ENTER VPA
                              </p>
                              <div className="flex gap-2">
                                <Input
                                  name="upiId"
                                  placeholder="username@bank"
                                  onChange={handlePaymentChange}
                                />
                                <Button variant="outline">Verify</Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}

                      {paymentMethod === "razorpay" && (
                        <div className="flex flex-col items-center justify-center h-full text-center space-y-4 animate-in fade-in slide-in-from-right-4 duration-300 py-8">
                          <div className="w-16 h-16 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                            <ShieldCheck className="w-8 h-8 text-white" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-lg">
                              Razorpay Secure Payment
                            </h3>
                            <p className="text-sm text-gray-500 max-w-xs mx-auto mt-1">
                              You will be redirected to the secure Razorpay
                              payment gateway to complete your transaction.
                            </p>
                          </div>
                          <div className="flex items-center gap-2 text-xs text-green-600 bg-green-50 px-3 py-1 rounded-full">
                            <Lock className="w-3 h-3" /> 256-bit SSL Encrypted
                          </div>
                        </div>
                      )}

                      {(paymentMethod === "netbanking" ||
                        paymentMethod === "wallet") && (
                        <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                          <h3 className="font-semibold text-lg mb-4">
                            Select{" "}
                            {paymentMethod === "netbanking" ? "Bank" : "Wallet"}
                          </h3>
                          <div className="grid grid-cols-2 gap-3">
                            {["HDFC", "SBI", "ICICI", "Axis"].map((bank) => (
                              <div
                                key={bank}
                                className="border p-3 rounded-lg text-center hover:border-primary cursor-pointer hover:bg-primary/5 transition-colors"
                              >
                                {bank}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-4 border-t border-gray-100">
                    <Button
                      variant="outline"
                      onClick={prevStep}
                      className="rounded-full px-6"
                      disabled={isSubmitting}
                    >
                      <ChevronLeft className="mr-2 h-4 w-4" /> Back
                    </Button>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center text-xs text-gray-500">
                        <Lock className="w-3 h-3 mr-1" /> Secure Transaction
                      </div>
                      <Button
                        onClick={handlePaymentAndBooking}
                        className="rounded-full px-8 min-w-[180px]"
                        disabled={isSubmitting}
                      >
                        {isSubmitting
                          ? paymentMethod === "razorpay"
                            ? "Redirecting..."
                            : "Processing..."
                          : paymentMethod === "razorpay"
                            ? "Proceed to Razorpay"
                            : `Pay ${services.find((s) => s.id === formData.selectedService)?.price}`}
                      </Button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </section>
    </>
  );
};

export default BookAppointment;
