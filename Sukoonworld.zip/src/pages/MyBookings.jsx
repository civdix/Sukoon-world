import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { getBookingsByEmail } from '@/lib/storage';
import { Search, Calendar, User, Clock } from 'lucide-react';
import { motion } from 'framer-motion';

const MyBookings = () => {
  const [email, setEmail] = useState('');
  const [bookings, setBookings] = useState(null);
  const [searched, setSearched] = useState(false);

  const handleSearch = (e) => {
    e.preventDefault();
    if (!email) return;
    const found = getBookingsByEmail(email);
    setBookings(found);
    setSearched(true);
  };

  return (
    <>
      <Helmet>
        <title>My Bookings - Sukoon World</title>
      </Helmet>
      
      <section className="py-20 min-h-screen bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold font-poppins text-secondary">My Booking History</h1>
            <p className="text-gray-600 mt-2">Enter your email to view your past and upcoming sessions</p>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 mb-8 max-w-xl mx-auto">
            <form onSubmit={handleSearch} className="flex gap-4">
              <div className="relative flex-grow">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <Input 
                  type="email" 
                  placeholder="Enter your email address" 
                  className="pl-10"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <Button type="submit">View History</Button>
            </form>
          </div>

          {searched && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              {bookings && bookings.length > 0 ? (
                bookings.map((booking) => (
                  <div key={booking.id} className="bg-white rounded-xl shadow-sm p-6 flex flex-col md:flex-row justify-between items-center border border-gray-100">
                    <div className="mb-4 md:mb-0">
                      <div className="flex items-center gap-3 mb-2">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium uppercase
                          ${booking.status === 'confirmed' ? 'bg-green-100 text-green-800' : 
                            booking.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                            'bg-gray-100 text-gray-800'}`}>
                          {booking.status}
                        </span>
                        <h3 className="font-semibold text-lg">{booking.service_type}</h3>
                      </div>
                      <div className="space-y-1 text-sm text-gray-600">
                        <div className="flex items-center gap-2"><User className="h-4 w-4" /> {booking.counsellor_name}</div>
                        <div className="flex items-center gap-2"><Calendar className="h-4 w-4" /> {booking.appointment_date}</div>
                        <div className="flex items-center gap-2"><Clock className="h-4 w-4" /> {booking.appointment_time}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-primary mb-2">{booking.price || 'Free'}</div>
                      <Button variant="outline" size="sm" disabled={booking.status === 'cancelled'}>
                        {booking.status === 'cancelled' ? 'Cancelled' : 'Reschedule'}
                      </Button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-10 text-gray-500">
                  No bookings found for this email address.
                </div>
              )}
            </motion.div>
          )}
        </div>
      </section>
    </>
  );
};

export default MyBookings;