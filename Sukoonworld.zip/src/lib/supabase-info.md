# Supabase Integration Guide for The Sukoon World

## Database Schema

To integrate Supabase with The Sukoon World booking system, you'll need to create the following table:

### Table: `bookings`